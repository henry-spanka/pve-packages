package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.1';
}

sub release {
	return '43';
}

sub repoid {
	return '1d4b0dfb';
}

# this is diplayed on the GUI
sub version_text {
    return '3.1-43/1d4b0dfb';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.1',
	'release' => '43',
	'repoid' => '1d4b0dfb',
    }
}

1;
