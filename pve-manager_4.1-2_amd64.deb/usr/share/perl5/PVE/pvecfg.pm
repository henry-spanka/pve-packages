package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.1';
}

sub release {
	return '2';
}

sub repoid {
	return '35fce76f';
}

# this is diplayed on the GUI
sub version_text {
    return '4.1-2/35fce76f';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.1',
	'release' => '2',
	'repoid' => '35fce76f',
    }
}

1;
