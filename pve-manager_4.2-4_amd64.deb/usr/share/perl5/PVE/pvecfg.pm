package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '4';
}

sub repoid {
	return 'cc7f45a2';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-4/cc7f45a2';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '4',
	'repoid' => 'cc7f45a2',
    }
}

1;
