package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.1';
}

sub release {
	return '1';
}

sub repoid {
	return '8f21fb45';
}

# this is diplayed on the GUI
sub version_text {
    return '4.1-1/8f21fb45';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.1',
	'release' => '1',
	'repoid' => '8f21fb45',
    }
}

1;
