package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.0';
}

sub release {
	return '4';
}

sub repoid {
	return 'ffc46cd0';
}

# this is diplayed on the GUI
sub version_text {
    return '4.0-4/ffc46cd0';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.0',
	'release' => '4',
	'repoid' => 'ffc46cd0',
    }
}

1;
