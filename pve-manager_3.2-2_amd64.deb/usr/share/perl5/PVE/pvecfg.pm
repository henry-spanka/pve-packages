package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.2';
}

sub release {
	return '2';
}

sub repoid {
	return '82599a65';
}

# this is diplayed on the GUI
sub version_text {
    return '3.2-2/82599a65';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.2',
	'release' => '2',
	'repoid' => '82599a65',
    }
}

1;
