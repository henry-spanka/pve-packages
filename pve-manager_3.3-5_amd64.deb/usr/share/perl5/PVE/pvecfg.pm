package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '5';
}

sub repoid {
	return '588eafaa';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-5/588eafaa';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '5',
	'repoid' => '588eafaa',
    }
}

1;
