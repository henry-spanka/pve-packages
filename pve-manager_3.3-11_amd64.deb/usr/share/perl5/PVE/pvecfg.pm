package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '11';
}

sub repoid {
	return '';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-11/';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '11',
	'repoid' => '',
    }
}

1;
