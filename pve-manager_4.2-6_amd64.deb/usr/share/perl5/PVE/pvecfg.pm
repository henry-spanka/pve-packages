package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '6';
}

sub repoid {
	return '34b3bc3e';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-6/34b3bc3e';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '6',
	'repoid' => '34b3bc3e',
    }
}

1;
