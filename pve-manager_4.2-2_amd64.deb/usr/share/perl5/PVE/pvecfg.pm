package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '2';
}

sub repoid {
	return '380d021c';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-2/380d021c';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '2',
	'repoid' => '380d021c',
    }
}

1;
