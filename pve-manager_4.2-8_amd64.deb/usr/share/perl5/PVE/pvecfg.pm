package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '8';
}

sub repoid {
	return '10547778';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-8/10547778';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '8',
	'repoid' => '10547778',
    }
}

1;
