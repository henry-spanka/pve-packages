package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '17';
}

sub repoid {
	return 'e2b5f34c';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-17/e2b5f34c';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '17',
	'repoid' => 'e2b5f34c',
    }
}

1;
