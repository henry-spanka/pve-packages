package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.0';
}

sub release {
	return '3';
}

sub repoid {
	return '4e9029bd';
}

# this is diplayed on the GUI
sub version_text {
    return '4.0-3/4e9029bd';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.0',
	'release' => '3',
	'repoid' => '4e9029bd',
    }
}

1;
