package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.0';
}

sub release {
	return '7';
}

sub repoid {
	return 'adb6c696';
}

# this is diplayed on the GUI
sub version_text {
    return '4.0-7/adb6c696';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.0',
	'release' => '7',
	'repoid' => 'adb6c696',
    }
}

1;
