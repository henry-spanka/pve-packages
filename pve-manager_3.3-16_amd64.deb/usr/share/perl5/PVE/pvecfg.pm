package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '16';
}

sub repoid {
	return '97194ea4';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-16/97194ea4';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '16',
	'repoid' => '97194ea4',
    }
}

1;
