package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '3';
}

sub repoid {
	return 'e8a62408';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-3/e8a62408';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '3',
	'repoid' => 'e8a62408',
    }
}

1;
