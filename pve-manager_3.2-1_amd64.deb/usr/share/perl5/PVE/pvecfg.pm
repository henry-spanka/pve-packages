package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.2';
}

sub release {
	return '1';
}

sub repoid {
	return '1933730b';
}

# this is diplayed on the GUI
sub version_text {
    return '3.2-1/1933730b';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.2',
	'release' => '1',
	'repoid' => '1933730b',
    }
}

1;
