package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.1';
}

sub release {
	return '20';
}

sub repoid {
	return 'c3aa0f1a';
}

# this is diplayed on the GUI
sub version_text {
    return '3.1-20/c3aa0f1a';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.1',
	'release' => '20',
	'repoid' => 'c3aa0f1a',
    }
}

1;
