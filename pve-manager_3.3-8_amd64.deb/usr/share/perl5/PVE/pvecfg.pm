package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '8';
}

sub repoid {
	return '';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-8/';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '8',
	'repoid' => '',
    }
}

1;
