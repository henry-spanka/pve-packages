package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.0';
}

sub release {
	return '2';
}

sub repoid {
	return 'fc539630';
}

# this is diplayed on the GUI
sub version_text {
    return '4.0-2/fc539630';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.0',
	'release' => '2',
	'repoid' => 'fc539630',
    }
}

1;
