package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.0';
}

sub release {
	return '1';
}

sub repoid {
	return '4025cbdb';
}

# this is diplayed on the GUI
sub version_text {
    return '4.0-1/4025cbdb';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.0',
	'release' => '1',
	'repoid' => '4025cbdb',
    }
}

1;
