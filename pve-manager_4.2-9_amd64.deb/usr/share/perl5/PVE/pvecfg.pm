package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '9';
}

sub repoid {
	return 'c5b28a1b';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-9/c5b28a1b';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '9',
	'repoid' => 'c5b28a1b',
    }
}

1;
