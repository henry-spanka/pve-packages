/* include/corosync/cs_config.h.  Generated from cs_config.h.in by configure.  */
/* Location of lcrso plugins */
#define LCRSODIR "/usr/lib/lcrso"

/* Location of sockets */
#define SOCKETDIR "/var/run"
