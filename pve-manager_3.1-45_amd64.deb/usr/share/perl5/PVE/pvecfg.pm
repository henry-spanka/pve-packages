package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.1';
}

sub release {
	return '45';
}

sub repoid {
	return 'b282dec2';
}

# this is diplayed on the GUI
sub version_text {
    return '3.1-45/b282dec2';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.1',
	'release' => '45',
	'repoid' => 'b282dec2',
    }
}

1;
