package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '5';
}

sub repoid {
	return '2288385c';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-5/2288385c';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '5',
	'repoid' => '2288385c',
    }
}

1;
