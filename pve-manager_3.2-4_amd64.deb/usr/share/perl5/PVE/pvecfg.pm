package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.2';
}

sub release {
	return '4';
}

sub repoid {
	return 'e24a91c1';
}

# this is diplayed on the GUI
sub version_text {
    return '3.2-4/e24a91c1';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.2',
	'release' => '4',
	'repoid' => 'e24a91c1',
    }
}

1;
