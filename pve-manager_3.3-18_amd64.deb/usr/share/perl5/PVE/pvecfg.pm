package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.3';
}

sub release {
	return '18';
}

sub repoid {
	return '380d021c';
}

# this is diplayed on the GUI
sub version_text {
    return '3.3-18/380d021c';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.3',
	'release' => '18',
	'repoid' => '380d021c',
    }
}

1;
