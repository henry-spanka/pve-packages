package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '4.2';
}

sub release {
	return '1';
}

sub repoid {
	return 'd14dae14';
}

# this is diplayed on the GUI
sub version_text {
    return '4.2-1/d14dae14';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '4.2',
	'release' => '1',
	'repoid' => 'd14dae14',
    }
}

1;
