package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.1';
}

sub release {
	return '16';
}

sub repoid {
	return '6a143a40';
}

# this is diplayed on the GUI
sub version_text {
    return '3.1-16/6a143a40';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.1',
	'release' => '16',
	'repoid' => '6a143a40',
    }
}

1;
