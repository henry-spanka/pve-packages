package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.1';
}

sub release {
	return '21';
}

sub repoid {
	return '93bf03d4';
}

# this is diplayed on the GUI
sub version_text {
    return '3.1-21/93bf03d4';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.1',
	'release' => '21',
	'repoid' => '93bf03d4',
    }
}

1;
