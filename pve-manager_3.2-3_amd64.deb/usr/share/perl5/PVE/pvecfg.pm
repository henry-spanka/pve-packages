package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.2';
}

sub release {
	return '3';
}

sub repoid {
	return '38bfef76';
}

# this is diplayed on the GUI
sub version_text {
    return '3.2-3/38bfef76';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.2',
	'release' => '3',
	'repoid' => '38bfef76',
    }
}

1;
