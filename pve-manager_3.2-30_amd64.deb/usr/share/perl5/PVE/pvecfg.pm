package PVE::pvecfg;

use strict;
use vars qw(@ISA);
use Carp;

sub package {
	return 'pve-manager';
}

sub version {
	return '3.2';
}

sub release {
	return '30';
}

sub repoid {
	return '1d095287';
}

# this is diplayed on the GUI
sub version_text {
    return '3.2-30/1d095287';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '3.2',
	'release' => '30',
	'repoid' => '1d095287',
    }
}

1;
